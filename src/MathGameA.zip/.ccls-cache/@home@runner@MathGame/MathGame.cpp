#include <iostream>
#include "Timer.cpp"

using namespace std;

int main() {
  Timer timer; 
  cout << "Timer started\n";
  int abs;
  cin >> abs;
  cout << "Elapsed time in seconds: " << timer.elapsed_seconds() << std::endl;
  return 0;
}